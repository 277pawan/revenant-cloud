# YAML configuration guides

Revenant uses one `revenant.yaml` per validation plan. SQL and MongoDB use
different check types because their schemas and query languages are different.

- [SQL YAML guide](./SQL_YAML.md) — PostgreSQL and MySQL syntax, every SQL
  check, connection settings, and a full example.
- [MongoDB YAML guide](./MONGODB_YAML.md) — MongoDB Atlas/self-hosted URI
  setup, discovery, every MongoDB check, inferred field types, and a full example.

Use `revenant init` to generate a starter config from a reachable database.
Review generated checks and add your own business rules before relying on them.
