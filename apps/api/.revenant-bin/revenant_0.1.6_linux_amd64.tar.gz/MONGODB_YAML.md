# MongoDB YAML guide (MongoDB Atlas and self-hosted MongoDB)

Revenant supports direct, read-only validation against MongoDB databases,
including Atlas. This is not an Atlas backup-restore drill: `verify` connects
to the database in the URI and runs read-only checks. Atlas restore orchestration
is not implemented.

## Protect the connection

If a URI containing a password has been pasted into chat, logs, or a committed
file, rotate that MongoDB database user's password before continuing.

Create a MongoDB user with read access only to the target database. Put its URI
in an environment variable or `.env` file excluded from source control:

```dotenv
MONGODB_URI=mongodb+srv://USER:PERCENT_ENCODED_PASSWORD@CLUSTER.mongodb.net/?retryWrites=true&w=majority
MONGODB_DATABASE=revenant_test
```

Percent-encode reserved characters in the username or password. For example,
`@` becomes `%40` and `/` becomes `%2F`. Atlas also requires the client IP to be
allowed in Network Access. Do not paste your real URI into `revenant.yaml` or
commit it.

The database name can instead appear in the URI path:

```dotenv
MONGODB_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/revenant_test?retryWrites=true&w=majority
```

If both `database.name` and a URI path are supplied, `database.name` selects the
database used by Revenant.

## Generate `revenant.yaml` from Atlas

With `MONGODB_URI` set, run:

```bash
revenant init --plan atlas-users --database revenant_test \
  --sample-size 100 --output revenant-mongodb.yaml
```

`--database` is optional when the URI already has a database path or
`MONGODB_DATABASE` is set. `--sample-size` is the maximum number of documents
read from each collection for field-type inference (default 100; allowed
range 1–10000).

The generated file includes collection names, estimated document counts, index
names, and observed field types. Counts from MongoDB's fast estimated-count
metadata are baselines, not authoritative exact counts; review the generated
`min` values. A manual `document_count` check runs an exact filtered count. It
checks a server-side JSON Schema validator when one exists, and supplements it
with a bounded document sample. **Sampling
cannot discover every field or every possible document shape.** Mixed types
are marked `mixed`, nested objects are represented with dotted field paths,
and array element shapes are not inferred. The generator never copies sample
document values into the YAML. Review the result and add domain-specific checks.

## MongoDB YAML shape

```yaml
plan: atlas-users

database:
  engine: mongodb
  connection: ${MONGODB_URI}
  name: ${MONGODB_DATABASE}

checks:
  - type: connect
  - type: collections
    expect_collections: [users, orders]
```

`database.name` is optional if the URI includes a database name; it is required
when the URI has no path. Environment placeholders in both `connection` and
`name` are expanded by the CLI.

## MongoDB checks

### `connect`

Pings MongoDB.

```yaml
- type: connect
```

### `collections`

Checks that each named collection exists in the selected database.

```yaml
- type: collections
  expect_collections: [users, orders, audit_events]
```

### `document_count`

Checks a collection's document count against an inclusive range. `max` is
optional. Optional `filter` is a MongoDB filter document; use it to count a
subset. `min: 0` checks that the query is valid without requiring any matches.

```yaml
- type: document_count
  collection: users
  min: 1
  max: 1000000

- type: document_count
  collection: orders
  filter:
    status: paid
  min: 1
```

### `document_schema`

Checks required fields across all documents and checks the BSON type of a field
when present. `required_fields` means every document must contain each listed
field. `expect_fields` does not imply required: it verifies types only on
documents where the field exists. Use both when a field must exist everywhere.

Supported expected types: `string`, `bool`, `int`, `long`, `double`, `decimal`,
`number`, `date`, `objectId`, `object`, `array`, `null`, and `mixed`.
`number` accepts numeric BSON types. `mixed` only checks that the field appears
in at least one document; it does not enforce a type.

```yaml
- type: document_schema
  collection: users
  required_fields: [name, email, active]
  expect_fields:
    name: string
    email: string
    age: int
    skills: array
    active: bool
    profile: object
    profile.city: string
```

Type assertions ignore documents where an optional field is absent, but fail
if the field is absent from every document. Required-field assertions scan all
documents, so on a large collection they may take time. Dotted paths address
nested object fields.

These assertions query the live collection rather than only the `init` sample.
Full document counts and per-field type/required assertions can scan large
collections and consume Atlas read capacity. Start with a small test database
or a narrowly scoped read-only user and review the checks before running them
against a large production cluster.

### `index`

On MongoDB, `index` requires `collection` and checks named indexes. The default
`_id_` index is present automatically but is not included in generated configs.

```yaml
- type: index
  collection: users
  expect_indexes: [email_1]
```

### `mongo_freshness`

Finds the newest BSON Date value at the selected field path and checks that it
is no older than `max_age`. Documents with a missing field or non-date value do
not count as the latest date.

```yaml
- type: mongo_freshness
  collection: events
  field: created_at
  max_age: 24h
```

Durations use Go duration syntax, such as `30m`, `24h`, or `168h`.

### `http_health`

This is database-independent and can be combined with MongoDB checks. It checks
an HTTP endpoint.

```yaml
- type: http_health
  name: application
  url: https://api.example.com/health
  method: GET       # defaults to GET
  expect_status: 200 # defaults to 200
```

## Full MongoDB example

```yaml
plan: atlas-users-recovery-check

database:
  engine: mongodb
  connection: ${MONGODB_URI}
  name: ${MONGODB_DATABASE}

checks:
  - type: connect
  - type: collections
    expect_collections: [users, orders]
  - type: document_count
    collection: users
    min: 1
  - type: document_schema
    collection: users
    required_fields: [name, email, active]
    expect_fields:
      name: string
      age: int
      email: string
      skills: array
      active: bool
  - type: index
    collection: users
    expect_indexes: [email_1]
  - type: mongo_freshness
    collection: orders
    field: created_at
    max_age: 48h
  - type: document_count
    collection: orders
    filter:
      status: paid
    min: 1
  - type: http_health
    name: application
    url: https://api.example.com/health
    method: GET
    expect_status: 200
```

Run:

```bash
revenant doctor --config revenant-mongodb.yaml
revenant verify --config revenant-mongodb.yaml
```

## MongoDB-only versus SQL-only types

MongoDB supports `connect`, `http_health`, `collections`, `document_count`,
`document_schema`, `mongo_freshness`, and MongoDB `index`.

PostgreSQL/MySQL support `connect`, `http_health`, `schema`, `row_count`,
`foreign_key`, `golden_query`, `freshness`, and SQL `index`.

SQL checks are rejected for MongoDB; MongoDB checks are rejected for SQL
engines. MongoDB aggregation pipelines, relationships/`$lookup`, Atlas backup
restore, and generated sample fixtures are not implemented in this version.
