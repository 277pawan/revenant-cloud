# SQL YAML guide (PostgreSQL and MySQL)

This guide covers SQL-backed validation for PostgreSQL and MySQL. MongoDB
uses different operators and check types; see [MONGODB_YAML.md](./MONGODB_YAML.md).

## Generate a starter config

Set `DATABASE_URL` in your shell or `.env`, then run:

```bash
revenant init --plan production --output revenant.yaml
```

The command reads the SQL catalog and baseline row counts, then generates
schema, row-count, foreign-key, and one simple golden-query check. Review the
file before relying on it. It does not read your application source or invent
business rules.

## Top-level YAML

```yaml
plan: production

database:
  engine: postgres # postgres or mysql
  connection: ${DATABASE_URL}

checks:
  - type: connect
```

Use `postgres://`, `postgresql://`, or `mysql://` URLs. Keep credentials in
environment variables or a secret store; do not commit a password in YAML.
MySQL TLS options are URL parameters, for example `?tls=true`.

## Optional AWS RDS recovery block

SQL plans can restore an AWS RDS PostgreSQL/MySQL snapshot before checks. This
does not apply to MongoDB Atlas.

```yaml
database:
  engine: postgres
  connection: postgres://${SANDBOX_USER}:${SANDBOX_PASSWORD}@${SANDBOX_ENDPOINT}:5432/${SANDBOX_DBNAME}?sslmode=require

recovery:
  engine: aws-rds
  source_identifier: production-db
  region: us-east-1
  use_freetier: true
  max_lifetime_minutes: 60
```

AWS credentials come from the AWS SDK environment/credential chain. The
temporary database login comes from `SANDBOX_USER`, `SANDBOX_PASSWORD`, and
`SANDBOX_DBNAME`; the CLI discovers `SANDBOX_ENDPOINT` after restoring. The
recovery TTL minimum is 10 minutes, or retain resources explicitly with
`retain_resources: true`. Use `revenant verify --keep-sandbox-on-failure` only
when you need to inspect a failed sandbox.

## SQL checks

### `connect`

Pings the selected SQL database.

```yaml
- type: connect
```

### `schema`

Requires every named table to exist. PostgreSQL currently checks `public`;
MySQL checks the selected database.

```yaml
- type: schema
  expect_tables: [users, orders, payments]
```

### `row_count`

Checks a table's row count against an inclusive range. `max` is optional.

```yaml
- type: row_count
  table: orders
  min: 1
  max: 1000000
```

### `foreign_key`

Checks that a single-column foreign key exists and that there are no orphan
child rows. Composite foreign keys are not supported.

```yaml
- type: foreign_key
  table: orders
  references: users
```

### `index`

Checks named indexes in PostgreSQL `public` or the selected MySQL database.

```yaml
- type: index
  expect_indexes: [orders_pkey, idx_orders_customer_id]
```

### `freshness`

Checks the latest timestamp in a column against a Go duration. Supported
examples include `30m`, `24h`, and `168h` (Go duration syntax does not define `d`, so express
days as hours).

```yaml
- type: freshness
  table: orders
  column: created_at
  max_age: 24h
```

### `golden_query`

Runs one SQL statement and expects its first result value to be an integer
at least `expect_min`. Use it for business rules that only your team knows.

```yaml
- type: golden_query
  query: "SELECT COUNT(*) FROM orders WHERE status = 'paid'"
  expect_min: 1
```

### `http_health`

Checks an HTTP endpoint alongside database assertions. `method` defaults to
`GET`, `expect_status` defaults to `200`, and `name` is optional.

```yaml
- type: http_health
  name: application
  url: https://api.example.com/health
  method: GET
  expect_status: 200
```

## Complete PostgreSQL example

```yaml
plan: production-smoke

database:
  engine: postgres
  connection: ${DATABASE_URL}

checks:
  - type: connect
  - type: schema
    expect_tables: [users, orders, payments]
  - type: row_count
    table: orders
    min: 1
  - type: foreign_key
    table: orders
    references: users
  - type: freshness
    table: orders
    column: created_at
    max_age: 48h
  - type: golden_query
    query: "SELECT COUNT(*) FROM orders WHERE status = 'paid'"
    expect_min: 1
```

Run `revenant verify --config revenant.yaml`. A failed assertion produces a
failed report and a non-zero exit status, suitable for CI.

## Current limitations

- SQL queries are read-only in intended use; `golden_query` is user-authored SQL.
- `golden_query` supports only one statement and reads an integer from the
  first column of the first row.
- SQL foreign-key validation supports single-column relationships.
- SQL AWS RDS restore flows support PostgreSQL/MySQL, not MongoDB Atlas.
- A full AWS RDS restore creates billable AWS resources until cleanup completes.
